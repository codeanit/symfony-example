<?php

namespace Api\PayoutBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;


class ApiPayoutBundle extends Bundle
{
}
